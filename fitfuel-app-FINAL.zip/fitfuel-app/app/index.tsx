/**
 * App Index
 * 
 * Entry point - redirects to welcome screen
 * In production, would check auth state and redirect accordingly
 */

import { useEffect } from 'react';
import { useRouter } from 'expo-router';

export default function Index() {
  const router = useRouter();

  useEffect(() => {
    // TODO: Check authentication state
    // For now, always go to welcome screen
    router.replace('/(auth)/welcome');
  }, []);

  return null;
}
