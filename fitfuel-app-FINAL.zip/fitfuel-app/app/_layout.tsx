/**
 * Root Layout
 * 
 * Main app layout with Expo Router configuration
 * Handles navigation structure and global providers
 */

import { Slot } from 'expo-router';
import { View } from 'react-native';
import { Theme } from './constants';

export default function RootLayout() {
  return (
    <View style={{ flex: 1, backgroundColor: Theme.colors.background }}>
      <Slot />
    </View>
  );
}
